/*
function stringToBytes(str) {
    const encoder = new TextEncoder();
    return encoder.encode(str);
}

  // Example usage
const myString = "Research-Project";
const bytes = stringToBytes(myString);

console.log(bytes);

*/

/*
function stringToBytes(str) {
    const encoder = new TextEncoder();
    const encodedBytes = encoder.encode(str);
    const bytes = Array.from(encodedBytes);
    return bytes;
  }
  
  // Example usage
  const myString = "Hello, world!";
  const bytes = stringToBytes(myString);
  console.log(bytes);
*/
/*
const {ethers} = require("ethers");

  function textToBytes32(text) {
    const encoder = new TextEncoder();
    const bytes = encoder.encode(text);
    const paddedBytes = new Uint8Array(32);
    paddedBytes.set(bytes.slice(0, 32));

    let hexString = '';
    for (let i = 0; i < paddedBytes.length; i++) {
      const byte = paddedBytes[i].toString(16).padStart(2, '0');
      hexString += byte;
    }

    return hexString;
  }

  const textInput = "Research-Project";
  const bytes32String = textToBytes32(textInput);
  console.log(bytes32String);
*/


  const { ethers } = require('ethers');

  function textToBytes32String(text) {
    let result = "";
    for (let i = 0; i < 32; i++) {
      if (i < text.length) {
        const charCode = text.charCodeAt(i);
        result += String.fromCharCode(charCode);
      } else {
        result += "\x00";
      }
    }
    return ethers.utils.formatBytes32String(result);
  }

  // Example usage:
  const inputText = "Research-Project";
  const bytes32String = textToBytes32String(inputText);
  console.log(bytes32String);


  /*
const { ethers } = require('ethers');

function utf8ToBytes32(text) {
  const encodedText = ethers.utils.toUtf8Bytes(text);
  let result = "0x";
  for (let i = 0; i < 32; i++) {
    if (i < encodedText.length) {
      result += encodedText[i].toString(16).padStart(2, '0');
    } else {
      result += "00";
    }
  }
  return result;
}

// Example usage:
const inputText = "Hello, world!";
const bytes32String = utf8ToBytes32(inputText);
console.log(bytes32String);
*/